
require('coffee-script/register');
require('./app')
